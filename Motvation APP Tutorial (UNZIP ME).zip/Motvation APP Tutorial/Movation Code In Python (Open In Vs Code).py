import tkinter as tk
import random

# Define the motivational messages
messages = [
    "Success is not final, failure is not fatal: it is the courage to continue that counts.",
    "Believe in yourself and all that you are. Know that there is something inside you that is greater than any obstacle.",
    "Don't watch the clock; do what it does. Keep going.",
    "The best way to predict the future is to create it.",
    "The only way to do great work is to love what you do. If you haven't found it yet, keep looking. Don't settle.",
    "You miss 100% of the shots you don't take.",
    "I can't change the direction of the wind, but I can adjust my sails to always reach my destination.",
    "The only limit to our realization of tomorrow will be our doubts of today.",
    "I have not failed. I've just found 10,000 ways that won't work.",
    "Do not go where the path may lead, go instead where there is no path and leave a trail.",
    "Don't let yesterday take up too much of today.",
    "You are never too old to set another goal or to dream a new dream.",
    "It does not matter how slowly you go as long as you do not stop.",
    "The future belongs to those who believe in the beauty of their dreams.",
    "Believe you can and you're halfway there.",
    "Your time is limited, don't waste it living someone else's life.",
    "Happiness is not something ready made. It comes from your own actions.",
    "Life is 10% what happens to us and 90% how we react to it.",
    "The greatest glory in living lies not in never falling, but in rising every time we fall.",
    "The only person you are destined to become is the person you decide to be."
]

# Define a function to display a random motivational message
def show_motivational_message():
    message = random.choice(messages)
    message_window = tk.Tk()
    message_window.title("Motivational Message")
    message_label = tk.Label(
        message_window,
        text=message,
        font=("Helvetica", 14),
        wraplength=400,
        justify="center",
        padx=20,
        pady=20
    )
    message_label.pack()
    copyright_label = tk.Label(
        message_window,
        text="\u00a9 Freddy Fazbear's Pizza, " + str(random.randint(1987, 2023)),
        font=("Helvetica", 8),
        justify="center",
        pady=10
    )
    copyright_label.pack()
    message_window.mainloop()

# Call the function to display a message
show_motivational_message()
